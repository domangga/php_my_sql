<?php 
    $con = mysqli_connect("localhost", "user", "12345", "sample");
?>
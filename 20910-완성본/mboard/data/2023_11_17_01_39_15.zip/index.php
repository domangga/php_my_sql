<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<meta http-equiv="refresh" content="0;url=./main/index.php">
<title>PHP+MySQL 입문</title>
</head>
<body>
</body>
</html>